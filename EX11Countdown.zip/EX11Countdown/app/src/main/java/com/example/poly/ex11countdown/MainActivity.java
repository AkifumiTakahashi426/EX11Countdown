package com.example.poly.ex11countdown;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView tvMinuteZan;
    private TextView tvSecondZan;
    private EditText etMinute;
    private EditText etSecond;
    SleepAsyncTask t;
    private int num;//カウントする秒数
    int minute;//秒数から分を抽出する数字
    int second;//秒数から秒を抽出する数字
    private int countNum;//カウントダウン表示用に調整する数字

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onButtonClick(View view) {
        //TextViewオブジェクトの取得
        //tvNum = findViewById(R.id.tvSecond);
        t = new SleepAsyncTask();

        etMinute = findViewById(R.id.etNinute);//分入力場所
        etSecond = findViewById(R.id.etSecond);//秒入力場所
        tvMinuteZan = findViewById(R.id.tvMinuteZan);//分表示場所
        tvSecondZan = findViewById(R.id.tvSecondZan);//秒表示場所


        //入力があった場合のみ数値を差し替え（なければ初期値0）
        if (etMinute.getText().length() != 0) {
            minute = Integer.parseInt(etMinute.getText().toString());
        }
        if (etSecond.getText().length() != 0) {
            second = Integer.parseInt(etSecond.getText().toString());
        }

        num = minute * 60 + second;//入力された数値をカウント用に秒に直す

        //カウントダウン表示用に作成した変数
        countNum = num - 1;

        //スレッドスタート
        t.execute();
    }


    private class SleepAsyncTask extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... Voids) {
            int nokori = 0;

            //入力された秒数分、1秒をカウントする
            for (int i = 0; i < num; i++) {

                //ストップボタンが押されてcancelがtrueであればfor文を抜ける
                if (t.isCancelled()) {
                    return null;
                }

                //カウントダウン
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                nokori = countNum - i;//残りの時間
                publishProgress(nokori);//残り時間を表示するメソッド
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... time) {//time…残り時間
            int minute = 0;
            int second = 0;

            minute = time[0] / 60;//分
            second = time[0] % 60;//秒

            //tvNum.setText(String.valueOf(time[0]));
            tvMinuteZan.setText(String.valueOf(minute));
            tvSecondZan.setText(String.valueOf(second));
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }

    }

    public void onButtonClickStop(View view) {
        //カウントダウンを抜ける準備（フラグをtrueにしておく）
        t.cancel(true);
        tvMinuteZan.setText("");
        tvSecondZan.setText("");
    }

}